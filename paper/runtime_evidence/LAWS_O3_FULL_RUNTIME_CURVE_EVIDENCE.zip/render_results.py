"""Render only the measurements from this five-size experiment."""
from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import ScalarFormatter,NullFormatter

ROOT=Path(__file__).resolve().parent
M=ROOT/'measurement'
summary=pd.read_csv(M/'tables/runtime_summary.csv').sort_values('n_events')
raw=pd.read_csv(M/'tables/scaling_timings.csv')
status=json.loads((M/'contracts/FINAL_STATUS.json').read_text())
assert status['compute_complete'] and status['protected_inputs_unchanged']
assert status['checks_passed']==status['checks_total']==540
assert summary.n_events.tolist()==[5,15,30,46,62]
assert summary.n_pairs.tolist()==[10,105,435,1035,1891]
for r in summary.itertuples():
    a=raw[raw.n_events==r.n_events]
    for col,boundary,count in [('first_pass','PRODUCTS_READY_TOTAL',3),('cached_pair','EVENT_CACHE_PAIR_RANK',9)]:
        v=a.loc[a.boundary==boundary,'wall_s'].to_numpy()
        assert len(v)==count and np.isfinite(v).all() and (v>0).all()
        for stat,value in [('median',np.median(v)),('min',v.min()),('max',v.max())]:
            assert np.isclose(getattr(r,f'{col}_{stat}_s'),value,rtol=1e-12,atol=1e-12)

dest=ROOT/'figures';dest.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,
                     'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none'})
fig,axs=plt.subplots(1,2,figsize=(11.2,5.0))
x=summary.n_pairs.to_numpy();events=summary.n_events.to_numpy()
for ax,label,title,color,count in zip(axs,['first_pass','cached_pair'],
        ['a  Initial processing','b  Repeated pair scoring'],['#1f5e97','#087e83'],[3,9]):
    y=summary[f'{label}_median_s'].to_numpy();lo=summary[f'{label}_min_s'].to_numpy();hi=summary[f'{label}_max_s'].to_numpy()
    ax.set_xscale('log');ax.set_yscale('log')
    ax.errorbar(x,y,yerr=np.vstack([y-lo,hi-y]),color=color,fmt='o-',lw=1.8,ms=6,capsize=4,
                label=f'Median; {count} technical measurements per size')
    ax.set_xticks(x,labels=[f'{int(v):,}' for v in x],rotation=30)
    ax.set_xlim(7,2600);ax.set_xlabel('Number of event pairs');ax.set_ylabel('Elapsed time (s)')
    ax.set_title(title,loc='left',pad=45,fontweight='bold')
    ax.yaxis.set_major_formatter(ScalarFormatter());ax.yaxis.set_minor_formatter(NullFormatter())
    ax.grid(True,which='major',color='#dce1e5',lw=.7);ax.set_axisbelow(True)
    top=ax.twiny();top.set_xscale('log');top.set_xlim(ax.get_xlim())
    top.set_xticks(x,labels=[str(int(n)) for n in events]);top.set_xlabel('Number of real O3 events',labelpad=7)
    top.minorticks_off();top.xaxis.set_minor_formatter(NullFormatter())
    ax.legend(loc='upper left',fontsize=8,frameon=False)
    ax.annotate(f'{y[-1]:.3f} s',(x[-1],y[-1]),xytext=(-4,12),textcoords='offset points',ha='right',color=color,fontsize=10)
    ax.set_ylim(max(min(lo)*.65,1e-4),max(hi)*1.85)
fig.subplots_adjust(left=.075,right=.985,bottom=.23,top=.76,wspace=.28)
fig.text(.5,.035,'New measurements only · Frozen DOMAIN04 / PATH1 implementation · RTX 5090 + 2 numeric CPU threads\n'
         'Bars show min–max technical variation, not confidence intervals. Lines connect measured points.',ha='center',fontsize=9,color='#444444')
for ext in ['png','pdf','svg']:fig.savefig(dest/f'O3_RUNTIME_CURVE.{ext}',dpi=250)
plt.close(fig)
summary.to_csv(dest/'O3_RUNTIME_CURVE_SOURCE.csv',index=False)
checks=json.loads((M/'results/checks.json').read_text())
maxdelta=max(r.get('max_abs_difference',0) for r in checks)
lines=['完整O3真实事件目录：五规模时间实验','日期：2026-10-06','',
       '本轮重新测量全部五个规模；图中没有旧58事件曲线，也没有采用上轮31.070秒或0.853秒作为终点。',
       '固定嵌套子集：按原62事件的事件名哈希排序取前5、15、30、46、62个，分别为10、105、435、1035、1891对。',
       '每个规模3次完整输入准备；每次准备后3次完整pair评分，共9次pair计时。首次完整处理包含其中第一次pair评分。',
       '轮次顺序预先冻结：5→15→30→46→62；62→46→30→15→5；30→5→62→15→46。没有选择最快一次。',
       '图中折线点为中位数，误差线为最小—最大值，均是技术重复，不是置信区间。','',
       '事件数 | 对数 | 首次完整处理中位数[最小,最大]秒 | 缓存后评分中位数[最小,最大]秒']
for r in summary.itertuples():
    lines.append(f'{r.n_events} | {r.n_pairs} | {r.first_pass_median_s:.6f} [{r.first_pass_min_s:.6f}, {r.first_pass_max_s:.6f}] | {r.cached_pair_median_s:.6f} [{r.cached_pair_min_s:.6f}, {r.cached_pair_max_s:.6f}]')
lines+=['','计时内容',
 '首次完整处理包括原始应变与参考噪声读取、PSD和预处理、短窗/16秒物理特征、三个seed全部模型分支、天空图读取与ordering/Nside512处理、三通道pair评分、共识排名和写出。',
 '缓存后评分复用事件级表征与已加载天空图，但每次重新计算全部pair及排名，不复用pair分数。',
 '不包括训练、下载、公开PE/天空图生成、Python导入和独立哈希/数值校验。没有清空操作系统缓存，不声称冷启动。',
 '沿用原速度实现：神经网络保留62个原生槽位，缺席事件补零；多余计算全部计时。这不是对小目录batch做了优化的缩放实验。',
 '', '本轮波动与旧单点的区别',
 '62事件的首次处理为73.115327、74.932858、102.968839秒，中位数74.932858秒；没有以旧单点31.070214秒替换本轮终点。',
 '对应天空图读取/ordering/Nside512步骤实测59.718656、61.042057、88.864386秒，是本轮首次处理波动的主要来源。原始分项记录保留了轮次对应关系。',
 '这说明端到端耗时受运行状态影响；未完成控制实验来分离硬件负载、文件缓存等原因，因此不能把与旧单点的差异解释为算法变慢或变快。缓存后配对另报，未将事件准备耗时隐去。',
 '', '版本',
 '原55.6秒对应的DOMAIN04/PATH1 NEW-SCORE-ONLY冻结实现；alpha=1，无外层旧新总分混合。不是C_PHYSICAL或XRUN联合模型的计时。',
 '本轮不运行Phazap，不添加注入，不训练模型，不调权，不改历史结果或论文。',
 '', '核验',f'540/540项检查通过，受保护输入哈希运行前后不变；三通道分数最大绝对偏差{maxdelta:.12g}，通过原atol=2e-4、rtol=1e-5容差。',
 '所有规模和所有重复的完整共识排名与冻结参考一致。事件对集合精确覆盖各自子集。',
 '实际2秒网络输入与独立留存的真实应变输入逐值一致；旧24秒对照缓存未迁移，未声称全24秒旧缓存逐值对照。计时仍从原始应变重新预处理。',
 '', '文件',
 'figures/O3_RUNTIME_CURVE.png、.pdf、.svg：两个子图，仅本轮新曲线。',
 'measurement/tables/runtime_summary.csv：五规模汇总。',
 'measurement/tables/scaling_timings.csv：15个首次处理及45个pair计时，另有15个准备计时。',
 'measurement/tables/stage_timings.csv：分步骤计时。',
 'measurement/round_1至round_3/results/：每个规模、每个seed、每次pair重复的结果。',
 'measurement/contracts/CONTRACT.json、FINAL_STATUS.json：预先冻结协议与验收。',
 '服务器：/root/autodl-tmp/gw-catalog/results/laws_o3_runtime_curve_20261006_r1/']
(ROOT/'RESULT_CN.txt').write_text('\n'.join(lines)+'\n')
record=dict(points_per_panel=5,new_data_only=True,old_58_curve_included=False,previous_62_measurement_included=False,
            first_pass_count=15,pair_measurement_count=45,source_sha256=hashlib.sha256((M/'tables/runtime_summary.csv').read_bytes()).hexdigest())
(dest/'FIGURE_AUDIT.json').write_text(json.dumps(record,indent=2)+'\n')
print(summary.to_string(index=False))
