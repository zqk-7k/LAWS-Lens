"""New full-O3 nested runtime curve; 3 fresh preparations and 9 pair timings per size."""
import os,sys,json,time,hashlib,shutil,traceback,subprocess,platform
from pathlib import Path
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:
    os.environ[key]='2'
sys.dont_write_bytecode=True
P=Path('/root/autodl-tmp/gw-catalog')
OLD=P/'results/trilens_speed_domain04_20260917T155616Z'
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(OLD/'scripts'),str(P/'scripts/experiments'),str(P)]
import trilens_scale_fixed_replay_20260917 as E
E.ROOT=HERE/'measurement';E.REPEATS=3;E.SIZES=(5,15,30,46,62)
ORDERS=((5,15,30,46,62),(62,46,30,15,5),(30,5,62,15,46))
BASE_ROOT=E.ROOT
E.FINAL='RUNTIME_CURVE_FULL_O3_NEW_MEASUREMENTS_ONLY_NO_PHAZAP'
E.ROOT.mkdir(exist_ok=False)
for name in ['contracts','scripts','tables','results','logs','reports','manifest','figures']:(E.ROOT/name).mkdir()
def protected_open(event,args):
    if event!='open' or not isinstance(args[0],(str,bytes,os.PathLike)):return
    p=Path(os.fsdecode(args[0])).resolve();mode=args[1];flags=args[2]
    writing=(isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
    if writing and p.is_relative_to(P) and not p.is_relative_to(HERE):raise RuntimeError('Historical output write denied: '+str(p))
sys.addaudithook(protected_open)
success=False;error=None
try:
    start=time.perf_counter()
    sys.path.insert(0,str(E.PREVIOUS/'scripts'))
    import trilens_frontend_pilot_20260917 as B
    import numpy as np,pandas as pd,torch
    from threadpoolctl import threadpool_limits
    import mcwf_path_fresh_confirmation_v2_20260908 as F
    import main_o3official_cfixed_v1 as CAT
    E.B,E.F,E.CAT,E.NP,E.PD,E.TORCH=B,F,CAT,np,pd,torch
    B.ROOT=E.ROOT;B.INPUTS={};B.CHECKS=[];B.TIMES=[];B.CONTEXT.update(method='SETUP',n_events=62,repetition=-1)
    threadpool_limits(2);torch.set_num_threads(2)
    def hardware():
        return dict(utc=pd.Timestamp.now(tz='UTC').isoformat(),python=platform.python_version(),torch=torch.__version__,cuda=torch.version.cuda,
            numpy=np.__version__,cpu_affinity=list(os.sched_getaffinity(0)),load=os.getloadavg(),
            cpu_model=next((s.split(':',1)[1].strip() for s in Path('/proc/cpuinfo').read_text().splitlines() if s.startswith('model name')),None),
            cpu_quota=Path('/sys/fs/cgroup/cpu.max').read_text().strip(),ram_limit=Path('/sys/fs/cgroup/memory.max').read_text().strip(),
            gpu=subprocess.check_output(['nvidia-smi','--query-gpu=name,driver_version,memory.used,utilization.gpu','--format=csv,noheader'],text=True).strip(),
            numeric_threads=2,no_OS_page_cache_flush=True)
    B.hardware=hardware
    E.js(E.ROOT/'contracts/IMPORT_TIMING.json',dict(seconds=time.perf_counter()-start,included_in_products_ready=False))
    E.js(E.ROOT/'contracts/HARDWARE_BEFORE.json',hardware())
    chosen=pd.read_csv(B.track(OLD/'contracts/selected_events.csv'))
    assert len(chosen)==chosen.event_name.nunique()==62
    added=['GW200208_222617','GW200220_061928','GW200308_173609','GW200322_091133']
    assert set(added)<=set(chosen.event_name)
    common=pd.read_csv(OLD/'contracts/common_events.csv')
    assert set(chosen.event_name)-set(common.event_name)==set(added)
    chosen.to_csv(E.ROOT/'contracts/selected_events.csv',index=False)
    E.status('READ_ONLY_INPUT_INVENTORY')
    # The legacy inventory loads a missing 24s comparison cache merely to obtain
    # metadata. Read that same frozen metadata directly; timed strain processing
    # remains unchanged. Verify actual 2s network inputs against the independently
    # archived C real-input arrays, then all legacy channel scores and exact ranks.
    original_real_inputs=F.dev.real_inputs
    F.dev.real_inputs=lambda dep:(None,pd.read_csv(F.dev.MAIN/'results/strict_h1l1_event_audit.csv'))
    rows,recipes=B.inventory(F,CAT,chosen)
    F.dev.real_inputs=original_real_inputs
    reference=P/'results/gwlr_unified_c_physical_20260918T134500Z_r1/completion/real_inputs/O3'
    reference_events=pd.read_parquet(B.track(reference/'events.parquet'))
    reference_short=np.load(B.track(reference/'raw2s.npy'))
    reference_lookup={name:i for i,name in enumerate(reference_events.event_name)}
    def verify(frozen,result,rows,recipes,n,rep):
        expected=reference_short[[reference_lookup[name] for name in rows.event_name.iloc[:n]]]
        actual=frozen.dev.TRAIN.make_window_view(result['full'],2)
        B.record_check(f'input2s_independent_frozen_replay_n{n}_r{rep}',np.array_equal(expected,actual),max_abs_delta=float(abs(expected-actual).max()))
        oldframes=[]
        for frame,recipe in zip(result['frames'],recipes):
            seed=recipe['seed']
            old=pd.read_parquet(B.ARCHIVE/f'development/evaluation/MCWF-UNIFIED-PATH875-DEVCONF/gwtc3/seed_{seed}/real_fusion_pairs.parquet')
            old=old.set_index('pair_key').loc[frame.pair_key].reset_index()
            for new_col,old_col in [('waveform_score','upstream_joint_waveform'),('time_score','time_score'),('sky_raw_log_bf','sky_raw_log_bf')]:
                a,b=frame[new_col].to_numpy(),old[old_col].to_numpy()
                B.record_check(f'score_replay_{new_col}_n{n}_r{rep}_s{seed}',np.allclose(a,b,atol=2e-4,rtol=1e-5),max_abs_difference=float(abs(a-b).max()))
            old['final_score']=old[['upstream_joint_waveform','time_score','sky_raw_log_bf']].to_numpy()@np.asarray(recipe['upstream_weights']);oldframes.append(old)
        B.record_check(f'consensus_replay_n{n}_r{rep}',B.rank_consensus(oldframes).pair_key.tolist()==result['consensus'].pair_key.tolist())
    B.verify_trilens=verify
    # Compare inputs used by this run with the archived speed experiment where tracked.
    old_inputs=pd.read_csv(OLD/'manifest/PROTECTED_INPUTS.csv').set_index('path')
    comparisons=[]
    for path,value in B.INPUTS.items():
        if path in old_inputs.index:
            expected=old_inputs.loc[path,'sha256_before'];assert value['sha256_before']==expected,path
            comparisons.append(dict(path=path,sha256=expected))
    E.js(E.ROOT/'contracts/ARCHIVED_INPUT_HASH_CHECK.json',dict(matched_inputs=len(comparisons),entries=comparisons))
    keys=sorted('--'.join(sorted(pair)) for pair in __import__('itertools').combinations(chosen.event_name,2))
    scopes=[]
    for n in E.SIZES:
        names=chosen.event_name.iloc[:n].tolist()
        pairkeys=sorted('--'.join(sorted(pair)) for pair in __import__('itertools').combinations(names,2))
        chosen.iloc[:n].to_csv(E.ROOT/f'contracts/events_n{n}.csv',index=False)
        scopes.append(dict(n_events=n,n_pairs=len(pairkeys),event_names=names,pair_key_sha256=hashlib.sha256(('\n'.join(pairkeys)+'\n').encode()).hexdigest()))
    contract=dict(code='LAWS-O3-RUNTIME-CURVE-20261006',events=62,pairs=1891,restored_events=added,scopes=scopes,
        original_runtime_baseline='TRILENS-SPEED-DOMAIN-04; frozen PATH1/NEW-SCORE-ONLY, alpha=1',
        not_C_PHYSICAL_checkpoint_benchmark=True,not_XRUN_joint_checkpoint_benchmark=True,
        task='Measure complete nested scaling curve from fixed62-event catalog; no old timing points or interpolation',
        seeds=[int(r['seed']) for r in recipes],phazap_executed=False,no_eligibility_filter=True,
        preparation_repeats_per_size=3,pair_repeats_per_preparation=3,pair_timings_per_size=9,round_orders=ORDERS,
        first_pair_pass_in_first_total=True,summary='median and min/max technical repeats; not confidence intervals',
        neural_batch_policy='Inherited62 native slots, zero-pad absent events; all extra compute charged, not an optimized small-batch implementation',
        boundaries=['Fresh input read + PSD/preprocessing + all feature/model branches + sky read + all within-subset pair scores + consensus/output',
                    'Cached event representations; recompute every pair and output; no reuse of pair scores'],
        excludes=['offline training','public PE and sky-map generation','downloads','Python imports','input integrity audit'],
        no_OS_page_cache_flush=True,no_cold_process_claim=True,numeric_cpu_threads=2,
        rank_replay='exact',score_replay=dict(atol=2e-4,rtol=1e-5),
        preprocessing_reference='Exact 2s model-input comparison to independently frozen C real strain; legacy full24 comparison cache absent. C model weights are NOT used.',
        pair_key_sha256=hashlib.sha256(('\n'.join(keys)+'\n').encode()).hexdigest(),
        engine_sha256=E.digest(Path(E.__file__)),frontend_sha256=E.digest(Path(B.__file__)),driver_sha256=E.digest(Path(__file__)),
        timing_comparison_note='New host, not directly comparable to the old 55.56s hardware measurement')
    E.js(E.ROOT/'contracts/CONTRACT.json',contract)
    E.js(E.ROOT/'contracts/FREEZE.json',dict(contract_sha256=E.digest(E.ROOT/'contracts/CONTRACT.json')))
    for f in [Path(__file__),Path(E.__file__),Path(B.__file__)]:shutil.copyfile(f,E.ROOT/'scripts'/f.name)
    alltimings=[];allchecks=[];allstages=[]
    for round_id,order in enumerate(ORDERS,1):
        E.ROOT=BASE_ROOT/f'round_{round_id}';B.ROOT=E.ROOT
        for name in ['contracts','scripts','tables','results','logs','reports','manifest','figures']:(E.ROOT/name).mkdir(parents=True,exist_ok=False)
        E.TIMINGS=[];B.CHECKS=[];B.TIMES=[]
        E.js(E.ROOT/'contracts/HARDWARE_BEFORE.json',hardware())
        for order_index,n in enumerate(order):
            E.js(BASE_ROOT/'contracts/PROGRESS.json',dict(round=round_id,n_events=n,order_index=order_index,total_cases=15,completed_cases=(round_id-1)*5+order_index))
            E.run_trilens(chosen,rows,recipes,n)
            pairkeys=sorted('--'.join(sorted(pair)) for pair in __import__('itertools').combinations(chosen.event_name.iloc[:n],2))
            for rep in range(E.REPEATS):
                q=pd.read_csv(E.ROOT/f'results/TriLens_n{n}/seed_{recipes[0]["seed"]}_rep{rep}.csv')
                B.record_check(f'pair_set_n{n}_rep{rep}',len(q)==n*(n-1)//2 and sorted(q.pair_key)==pairkeys)
            E.js(BASE_ROOT/'contracts/PROGRESS.json',dict(round=round_id,n_events=n,total_cases=15,completed_cases=(round_id-1)*5+order_index+1))
        alltimings.extend(dict(round=round_id,**v) for v in E.TIMINGS)
        allchecks.extend(dict(round=round_id,**v) for v in B.CHECKS)
        allstages.extend(dict(round=round_id,**v) for v in B.TIMES)
        E.js(E.ROOT/'contracts/HARDWARE_AFTER.json',hardware())
    E.ROOT=BASE_ROOT;B.ROOT=BASE_ROOT;E.TIMINGS=alltimings;B.CHECKS=allchecks;B.TIMES=allstages
    timing=pd.DataFrame(alltimings);timing.to_csv(BASE_ROOT/'tables/scaling_timings.csv',index=False)
    pd.DataFrame(allstages).to_csv(BASE_ROOT/'tables/stage_timings.csv',index=False)
    E.js(BASE_ROOT/'results/checks.json',allchecks)
    summaries=[]
    for n in E.SIZES:
        t=timing[timing.n_events==n]
        prep=t.loc[t.boundary=='PREPARE_EVENTS','wall_s'].to_numpy()
        first=t.loc[t.boundary=='PRODUCTS_READY_TOTAL','wall_s'].to_numpy()
        cached=t.loc[t.boundary=='EVENT_CACHE_PAIR_RANK','wall_s'].to_numpy()
        assert len(prep)==len(first)==3 and len(cached)==9
        row=dict(method='LAWS-Lens (archived DOMAIN04 implementation)',n_events=n,n_pairs=n*(n-1)//2,fresh_repeats=3,cached_pair_timings=9)
        for label,values in [('preparation',prep),('first_pass',first),('cached_pair',cached)]:
            for stat,value in [('median',np.median(values)),('min',values.min()),('max',values.max())]:row[f'{label}_{stat}_s']=float(value)
        summaries.append(row)
    pd.DataFrame(summaries).to_csv(BASE_ROOT/'tables/runtime_summary.csv',index=False)
    success=True
except BaseException as exc:
    error=repr(exc);(E.ROOT/'logs/FAIL.txt').write_text(traceback.format_exc());raise
finally:
    if E.ROOT!=BASE_ROOT:
        if E.B is not None and 'allchecks' in globals():B.CHECKS=allchecks+[dict(round=round_id,**v) for v in B.CHECKS]
        E.ROOT=BASE_ROOT
        if E.B is not None:B.ROOT=BASE_ROOT
    E.finish(success,error)
